function Header() {
  return (
    <header>
      <h2>Witaj w Pokedex v2!</h2>
    </header>
  );
}

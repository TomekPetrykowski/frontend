function Loading() {
  return (
    <div className="loading">
      <img src="./public/pokeball.svg" alt="loading animation" />
      <p>Łapanie pokemonów...</p>
    </div>
  );
}
